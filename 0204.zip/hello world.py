# -*- coding: utf-8 -*-
"""
Created on Sat Sep 30 15:54:11 2017

@author: Anthony
"""

print('Hello World')

print(1+1)

var = 5
